# Fake Message Studio - Mobile Interface Design

## Overall Layout

The mobile interface will use a step-by-step wizard approach to guide users through the process of creating fake message story videos. This approach is more suitable for mobile screens than the desktop's all-in-one dashboard.

## Screen Designs

### 1. Welcome Screen
- App logo and name
- "Create New Story" button
- "My Projects" button to access saved projects
- Brief tutorial/walkthrough option for first-time users

### 2. Script Input Screen
- Large text area optimized for mobile typing
- Character name tags with color coding
- Simple formatting toolbar (emoji, bold, etc.)
- Character management panel (add/remove characters)
- "Next" button to proceed to voice selection

### 3. Voice Selection Screen
- List of available characters from the script
- Voice selection dropdown for each character
- Preview button to test selected voices
- Voice customization options (pitch, speed)
- "Back" and "Next" navigation buttons

### 4. Background Selection Screen
- Visual grid of background options
- Categories for different background types:
  - Gaming (Minecraft, etc.)
  - Urban (Subway, Street, etc.)
  - ASMR/Relaxing
  - Abstract/Patterns
- Preview option for each background
- "Back" and "Next" navigation buttons

### 5. Preview & Customize Screen
- Preview of generated message screenshots
- Options to adjust:
  - Message bubble style
  - Font style and size
  - Timing between messages
  - Background opacity/blur
- "Back" and "Generate" buttons

### 6. Video Generation Screen
- Progress indicator during video creation
- Cancel button
- Preview of video sections as they're generated
- Estimated time remaining

### 7. Final Video Screen
- Video player with basic controls
- Download button
- Share buttons for social media platforms
- "Create New" button
- "Edit" button to return to customization

## Navigation

- Bottom navigation bar with icons for:
  - Home
  - Projects
  - Settings
  - Help
- Step indicator at top of screen during creation process
- Swipe gestures for moving between compatible screens

## Mobile-Specific UI Elements

### Portrait Mode
- Vertical layout optimized for one-handed operation
- Bottom-aligned action buttons within thumb reach
- Collapsible panels for advanced options

### Landscape Mode
- Two-column layout where appropriate
- Video preview on one side, controls on the other
- Expanded keyboard area for script input

### Touch Optimizations
- Large touch targets (minimum 48x48dp)
- Swipe gestures for common actions
- Pinch-to-zoom for video preview
- Haptic feedback for important actions

## Color Scheme & Typography

- Dark mode by default to save battery and reduce eye strain
- Light mode option available
- High contrast for accessibility
- Limited color palette:
  - Primary: #5C6BC0 (Indigo)
  - Secondary: #26A69A (Teal)
  - Accent: #FF7043 (Deep Orange)
  - Background: #121212 (Dark Gray)
  - Text: #FFFFFF (White) / #E0E0E0 (Light Gray)
- Typography:
  - Sans-serif system fonts for optimal performance
  - Large, readable text (minimum 16px)
  - Clear hierarchy with distinct heading styles
