# Fake Message Studio - Mobile Version

This is a mobile-compatible version of Diffusion Studio's fake message stories feature, allowing users to create animated videos with voice acting and customizable backgrounds based on message scripts.

## Features

- Script input for fake message conversations
- Voice selection for different characters
- Background selection (Minecraft parkour, subway scenes, etc.)
- Message visualization with different styles
- Video generation with voice narration
- Mobile-optimized interface that works on phones

## Technology Stack

- React.js with React Hooks
- Material UI for mobile-friendly components
- Web Audio API for voice synthesis
- HTML5 Canvas for video rendering
- Vite for fast development and optimized builds

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

### Installation

1. Clone the repository
2. Install dependencies:
```
npm install
```
3. Start the development server:
```
npm run dev
```
4. Open your browser to the URL shown in the terminal (typically http://localhost:3000)

## Usage

1. Enter your message script in the format "Character: Message"
2. Select voices for each character
3. Choose a background for your video
4. Preview and customize the message appearance
5. Generate the video
6. Download or share the final video

## Mobile Compatibility

This application is specifically designed for mobile devices and works in both portrait and landscape orientations. It provides a step-by-step wizard interface that's optimized for touch interactions.

## Deployment

To build for production:
```
npm run build
```

The built files will be in the `dist` directory and can be deployed to any static hosting service.

## License

This project is for demonstration purposes only.
