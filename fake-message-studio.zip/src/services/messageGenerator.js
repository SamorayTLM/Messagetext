import React from 'react';

// This service handles the generation of message bubbles from script text
class MessageGenerator {
  /**
   * Parse script text into message objects
   * @param {string} scriptText - The raw script text
   * @returns {Array} Array of message objects
   */
  static parseScript(scriptText) {
    if (!scriptText) return [];
    
    const lines = scriptText.split('\n');
    const parsedMessages = [];
    
    lines.forEach(line => {
      // Match pattern: "Character: Message"
      const match = line.match(/^([A-Za-z0-9_]+):\s*(.*)/);
      if (match && match[1] && match[2]) {
        parsedMessages.push({
          sender: match[1],
          text: match[2],
          timestamp: new Date().toISOString() // In a real app, we'd generate realistic timestamps
        });
      }
    });
    
    return parsedMessages;
  }
  
  /**
   * Generate message bubble HTML/CSS based on style
   * @param {Object} message - Message object
   * @param {string} style - Style name (modern, classic, bubble)
   * @param {boolean} isUser - Whether this message is from the user
   * @returns {Object} Style object for the message bubble
   */
  static getMessageStyle(style, isUser) {
    const styles = {
      modern: {
        container: {
          display: 'flex',
          justifyContent: isUser ? 'flex-end' : 'flex-start',
          marginBottom: '12px',
        },
        bubble: {
          padding: '12px',
          maxWidth: '80%',
          borderRadius: '16px',
          backgroundColor: isUser ? '#5C6BC0' : '#1E1E1E',
          color: isUser ? '#FFFFFF' : '#E0E0E0',
        }
      },
      classic: {
        container: {
          display: 'flex',
          justifyContent: isUser ? 'flex-end' : 'flex-start',
          marginBottom: '12px',
        },
        bubble: {
          padding: '12px',
          maxWidth: '80%',
          borderRadius: '4px',
          backgroundColor: isUser ? '#26A69A' : '#1E1E1E',
          color: isUser ? '#FFFFFF' : '#E0E0E0',
        }
      },
      bubble: {
        container: {
          display: 'flex',
          justifyContent: isUser ? 'flex-end' : 'flex-start',
          marginBottom: '12px',
        },
        bubble: {
          padding: '12px',
          maxWidth: '80%',
          borderRadius: '20px',
          backgroundColor: isUser ? '#FF7043' : '#1E1E1E',
          color: isUser ? '#FFFFFF' : '#E0E0E0',
        }
      }
    };
    
    return styles[style] || styles.modern;
  }
  
  /**
   * Create a canvas element with rendered message bubbles
   * @param {Array} messages - Array of message objects
   * @param {string} style - Style name
   * @param {Object} characters - Map of character names to determine who is the "user"
   * @returns {HTMLCanvasElement} Canvas with rendered messages
   */
  static renderToCanvas(messages, style, characters) {
    // This is a simplified implementation
    // In a real app, this would create an actual canvas with rendered messages
    
    const canvas = document.createElement('canvas');
    canvas.width = 360;  // Mobile width
    canvas.height = messages.length * 80 + 40;  // Height based on number of messages
    
    const ctx = canvas.getContext('2d');
    
    // Fill background
    ctx.fillStyle = '#121212';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // In a real implementation, we would render each message bubble here
    // For now, we'll just return the empty canvas
    
    return canvas;
  }
}

export default MessageGenerator;
