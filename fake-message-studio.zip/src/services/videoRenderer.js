class VideoRenderer {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.width = 360; // Default mobile width
    this.height = 640; // Default mobile height
    this.frameRate = 30;
    this.initialized = false;
  }

  /**
   * Initialize the video renderer
   * @param {number} width - Canvas width
   * @param {number} height - Canvas height
   * @returns {boolean} Success status
   */
  initialize(width = 360, height = 640) {
    try {
      this.width = width;
      this.height = height;
      
      // Create canvas
      this.canvas = document.createElement('canvas');
      this.canvas.width = width;
      this.canvas.height = height;
      this.ctx = this.canvas.getContext('2d');
      
      this.initialized = true;
      return true;
    } catch (error) {
      console.error('Error initializing VideoRenderer:', error);
      return false;
    }
  }

  /**
   * Load a background image
   * @param {string} backgroundId - ID of the background to use
   * @returns {Promise<HTMLImageElement>} Promise that resolves with the loaded image
   */
  loadBackground(backgroundId) {
    return new Promise((resolve, reject) => {
      // In a real app, we would load the actual image
      // For this demo, we'll create a colored background
      
      const backgroundColors = {
        minecraft: '#507D2A', // Green for Minecraft
        subway: '#303030', // Dark gray for subway
        asmr: '#2D3047', // Dark blue for ASMR studio
        nature: '#2E5902', // Forest green
        beach: '#00A5CF', // Ocean blue
        citynight: '#0F1626', // Dark blue for night city
        gaming: '#7D1D3F', // Red for gaming
        space: '#0B0C10', // Black for space
      };
      
      const color = backgroundColors[backgroundId] || '#121212';
      
      // Create a simple colored background
      const img = new Image();
      img.width = this.width;
      img.height = this.height;
      
      // Create a temporary canvas to generate the background
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = this.width;
      tempCanvas.height = this.height;
      const tempCtx = tempCanvas.getContext('2d');
      
      // Fill with color
      tempCtx.fillStyle = color;
      tempCtx.fillRect(0, 0, this.width, this.height);
      
      // Add some simple patterns based on the background type
      if (backgroundId === 'minecraft') {
        // Add grid pattern for Minecraft
        tempCtx.strokeStyle = '#3B5D1F';
        tempCtx.lineWidth = 2;
        const gridSize = 30;
        
        for (let x = 0; x < this.width; x += gridSize) {
          tempCtx.beginPath();
          tempCtx.moveTo(x, 0);
          tempCtx.lineTo(x, this.height);
          tempCtx.stroke();
        }
        
        for (let y = 0; y < this.height; y += gridSize) {
          tempCtx.beginPath();
          tempCtx.moveTo(0, y);
          tempCtx.lineTo(this.width, y);
          tempCtx.stroke();
        }
      } else if (backgroundId === 'subway') {
        // Add some lines for subway
        tempCtx.strokeStyle = '#505050';
        tempCtx.lineWidth = 5;
        
        for (let y = 100; y < this.height; y += 150) {
          tempCtx.beginPath();
          tempCtx.moveTo(0, y);
          tempCtx.lineTo(this.width, y);
          tempCtx.stroke();
        }
      }
      
      // Convert the canvas to a data URL
      const dataUrl = tempCanvas.toDataURL();
      
      // Load the data URL into the image
      img.onload = () => resolve(img);
      img.onerror = (err) => reject(err);
      img.src = dataUrl;
    });
  }

  /**
   * Render a frame of the video
   * @param {HTMLImageElement} background - Background image
   * @param {Array} messages - Array of messages to display
   * @param {number} frameIndex - Current frame index
   * @param {Object} options - Rendering options
   * @returns {HTMLCanvasElement} Canvas with the rendered frame
   */
  renderFrame(background, messages, frameIndex, options = {}) {
    if (!this.initialized) {
      this.initialize();
    }
    
    const { messageStyle = 'modern', animationSpeed = 1 } = options;
    
    // Clear canvas
    this.ctx.clearRect(0, 0, this.width, this.height);
    
    // Draw background
    if (background) {
      this.ctx.drawImage(background, 0, 0, this.width, this.height);
      
      // Add overlay to make text more readable
      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      this.ctx.fillRect(0, 0, this.width, this.height);
    }
    
    // Calculate how many messages to show based on frame index and animation speed
    const messagesToShow = Math.min(
      Math.floor(frameIndex * animationSpeed / 30) + 1,
      messages.length
    );
    
    // Draw messages
    let y = 40;
    for (let i = 0; i < messagesToShow; i++) {
      const message = messages[i];
      const isUser = message.sender === messages[0].sender; // Assume first sender is user
      
      // Draw message bubble
      y = this.drawMessageBubble(message, isUser, y, messageStyle);
    }
    
    return this.canvas;
  }

  /**
   * Draw a message bubble on the canvas
   * @param {Object} message - Message object
   * @param {boolean} isUser - Whether this message is from the user
   * @param {number} y - Y position to start drawing
   * @param {string} style - Style name
   * @returns {number} New Y position after drawing
   */
  drawMessageBubble(message, isUser, y, style) {
    const padding = 12;
    const maxWidth = this.width * 0.7;
    
    // Set text properties
    this.ctx.font = '16px Arial';
    this.ctx.textBaseline = 'top';
    
    // Measure text
    const textMetrics = this.ctx.measureText(message.text);
    const textHeight = 16 * 1.2; // Approximate height based on font size
    
    // Calculate bubble dimensions
    const bubbleWidth = Math.min(textMetrics.width + padding * 2, maxWidth);
    const bubbleHeight = textHeight + padding * 2;
    
    // Calculate bubble position
    const bubbleX = isUser ? this.width - bubbleWidth - 20 : 20;
    
    // Draw sender name if not user
    if (!isUser) {
      this.ctx.fillStyle = '#AAAAAA';
      this.ctx.font = 'bold 14px Arial';
      this.ctx.fillText(message.sender, bubbleX, y);
      y += 20;
    }
    
    // Draw bubble
    this.ctx.fillStyle = isUser ? '#5C6BC0' : '#1E1E1E';
    
    if (style === 'classic') {
      this.ctx.fillStyle = isUser ? '#26A69A' : '#1E1E1E';
      this.roundRect(bubbleX, y, bubbleWidth, bubbleHeight, 4);
    } else if (style === 'bubble') {
      this.ctx.fillStyle = isUser ? '#FF7043' : '#1E1E1E';
      this.roundRect(bubbleX, y, bubbleWidth, bubbleHeight, 20);
    } else {
      // Modern style (default)
      this.roundRect(bubbleX, y, bubbleWidth, bubbleHeight, 16);
    }
    
    // Draw text
    this.ctx.fillStyle = '#FFFFFF';
    this.ctx.font = '16px Arial';
    this.ctx.fillText(message.text, bubbleX + padding, y + padding, maxWidth - padding * 2);
    
    return y + bubbleHeight + 16; // Return new Y position
  }

  /**
   * Helper function to draw rounded rectangles
   * @param {number} x - X position
   * @param {number} y - Y position
   * @param {number} width - Rectangle width
   * @param {number} height - Rectangle height
   * @param {number} radius - Corner radius
   */
  roundRect(x, y, width, height, radius) {
    this.ctx.beginPath();
    this.ctx.moveTo(x + radius, y);
    this.ctx.lineTo(x + width - radius, y);
    this.ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    this.ctx.lineTo(x + width, y + height - radius);
    this.ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    this.ctx.lineTo(x + radius, y + height);
    this.ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    this.ctx.lineTo(x, y + radius);
    this.ctx.quadraticCurveTo(x, y, x + radius, y);
    this.ctx.closePath();
    this.ctx.fill();
  }

  /**
   * Generate a video from a sequence of frames
   * @param {Object} project - Project data
   * @param {Function} progressCallback - Callback for progress updates
   * @returns {Promise<Blob>} Promise that resolves with the video blob
   */
  async generateVideo(project, progressCallback = () => {}) {
    if (!this.initialized) {
      this.initialize();
    }
    
    const { script, characters, selectedVoices, selectedBackground, messageStyle } = project;
    
    try {
      // Update progress
      progressCallback(0, 'Preparing assets...');
      
      // Parse script into messages
      const MessageGenerator = (await import('./messageGenerator')).default;
      const messages = MessageGenerator.parseScript(script);
      
      // Load background
      const background = await this.loadBackground(selectedBackground);
      
      // Update progress
      progressCallback(20, 'Generating message bubbles...');
      
      // In a real implementation, we would:
      // 1. Generate audio for each message
      // 2. Create a MediaRecorder to record the canvas
      // 3. Animate the messages appearing one by one
      // 4. Combine audio and video
      
      // For this demo, we'll simulate the process with a timeout
      await new Promise(resolve => setTimeout(resolve, 1000));
      progressCallback(40, 'Processing audio...');
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      progressCallback(60, 'Rendering video frames...');
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      progressCallback(80, 'Finalizing video...');
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      progressCallback(100, 'Video generation complete!');
      
      // In a real app, we would return the actual video blob
      // For this demo, we'll return a placeholder
      return new Blob(['fake video data'], { type: 'video/mp4' });
      
    } catch (error) {
      console.error('Error generating video:', error);
      throw error;
    }
  }
}

export default new VideoRenderer();
