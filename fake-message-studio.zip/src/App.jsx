import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { AppContextProvider } from './contexts/AppContext';

// Import screens
import Welcome from './components/screens/Welcome';
import ScriptInput from './components/screens/ScriptInput';
import VoiceSelection from './components/screens/VoiceSelection';
import BackgroundSelection from './components/screens/BackgroundSelection';
import Preview from './components/screens/Preview';
import VideoGeneration from './components/screens/VideoGeneration';
import FinalVideo from './components/screens/FinalVideo';

// Create theme
const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#5C6BC0',
    },
    secondary: {
      main: '#26A69A',
    },
    error: {
      main: '#CF6679',
    },
    background: {
      default: '#121212',
      paper: '#1E1E1E',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    fontSize: 16,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
          padding: '12px 16px',
          minHeight: 48,
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          marginBottom: 16,
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <AppContextProvider>
        <div className="app-container">
          <Routes>
            <Route path="/" element={<Welcome />} />
            <Route path="/script" element={<ScriptInput />} />
            <Route path="/voices" element={<VoiceSelection />} />
            <Route path="/background" element={<BackgroundSelection />} />
            <Route path="/preview" element={<Preview />} />
            <Route path="/generate" element={<VideoGeneration />} />
            <Route path="/video" element={<FinalVideo />} />
          </Routes>
        </div>
      </AppContextProvider>
    </ThemeProvider>
  );
}

export default App;
