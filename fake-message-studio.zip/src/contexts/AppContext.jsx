import React, { createContext, useContext, useState } from 'react';

// Create context
const AppContext = createContext();

// Custom hook to use the context
export const useAppContext = () => useContext(AppContext);

export const AppContextProvider = ({ children }) => {
  // State for the current project
  const [project, setProject] = useState({
    script: '',
    characters: [],
    selectedVoices: {},
    selectedBackground: null,
    messageStyle: 'modern',
    generatedVideo: null,
  });

  // State for application settings
  const [settings, setSettings] = useState({
    darkMode: true,
    autoSave: true,
    quality: 'medium', // low, medium, high
  });

  // State for UI
  const [ui, setUi] = useState({
    currentStep: 0,
    isLoading: false,
    error: null,
  });

  // Function to update project data
  const updateProject = (newData) => {
    setProject(prev => ({ ...prev, ...newData }));
  };

  // Function to update settings
  const updateSettings = (newSettings) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  // Function to update UI state
  const updateUi = (newUiState) => {
    setUi(prev => ({ ...prev, ...newUiState }));
  };

  // Function to reset project
  const resetProject = () => {
    setProject({
      script: '',
      characters: [],
      selectedVoices: {},
      selectedBackground: null,
      messageStyle: 'modern',
      generatedVideo: null,
    });
    updateUi({ currentStep: 0 });
  };

  // Function to save project to local storage
  const saveProject = () => {
    try {
      localStorage.setItem('fakeMessageStudio_currentProject', JSON.stringify(project));
      return true;
    } catch (error) {
      console.error('Error saving project:', error);
      return false;
    }
  };

  // Function to load project from local storage
  const loadProject = () => {
    try {
      const savedProject = localStorage.getItem('fakeMessageStudio_currentProject');
      if (savedProject) {
        setProject(JSON.parse(savedProject));
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error loading project:', error);
      return false;
    }
  };

  // Value object to be provided to consumers
  const value = {
    project,
    settings,
    ui,
    updateProject,
    updateSettings,
    updateUi,
    resetProject,
    saveProject,
    loadProject,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
