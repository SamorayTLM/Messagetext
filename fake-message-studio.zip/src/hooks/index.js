import React, { useState, useEffect } from 'react';

/**
 * Custom hook for responsive design
 * @param {Object} breakpoints - Object with breakpoint values
 * @returns {Object} Current breakpoint information
 */
export const useMediaQuery = (breakpoints = {
  xs: 0,
  sm: 600,
  md: 960,
  lg: 1280,
  xl: 1920
}) => {
  const [screenSize, setScreenSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight
  });
  
  const [currentBreakpoint, setCurrentBreakpoint] = useState('xs');
  const [orientation, setOrientation] = useState(
    window.innerWidth > window.innerHeight ? 'landscape' : 'portrait'
  );

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      
      setScreenSize({ width, height });
      setOrientation(width > height ? 'landscape' : 'portrait');
      
      // Determine current breakpoint
      if (width >= breakpoints.xl) {
        setCurrentBreakpoint('xl');
      } else if (width >= breakpoints.lg) {
        setCurrentBreakpoint('lg');
      } else if (width >= breakpoints.md) {
        setCurrentBreakpoint('md');
      } else if (width >= breakpoints.sm) {
        setCurrentBreakpoint('sm');
      } else {
        setCurrentBreakpoint('xs');
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial call
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [breakpoints]);

  return {
    screenSize,
    currentBreakpoint,
    orientation,
    isMobile: currentBreakpoint === 'xs' || currentBreakpoint === 'sm',
    isTablet: currentBreakpoint === 'md',
    isDesktop: currentBreakpoint === 'lg' || currentBreakpoint === 'xl',
    isPortrait: orientation === 'portrait',
    isLandscape: orientation === 'landscape'
  };
};

/**
 * Custom hook for local storage
 * @param {string} key - Storage key
 * @param {any} initialValue - Initial value
 * @returns {Array} [storedValue, setValue]
 */
export const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return initialValue;
    }
  });

  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  };

  return [storedValue, setValue];
};

/**
 * Custom hook for audio processing
 * @returns {Object} Audio processing functions
 */
export const useAudioProcessing = () => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [availableVoices, setAvailableVoices] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const initializeAudio = async () => {
      try {
        setIsLoading(true);
        const AudioProcessor = (await import('../services/audioProcessor')).default;
        await AudioProcessor.initialize();
        setAvailableVoices(AudioProcessor.getAvailableVoices());
        setIsInitialized(true);
        setIsLoading(false);
      } catch (err) {
        console.error('Failed to initialize audio:', err);
        setError('Failed to initialize audio processing');
        setIsLoading(false);
      }
    };

    initializeAudio();
  }, []);

  const generateSpeech = async (text, voiceId) => {
    try {
      setIsLoading(true);
      const AudioProcessor = (await import('../services/audioProcessor')).default;
      const audioBuffer = await AudioProcessor.generateSpeech(text, voiceId);
      setIsLoading(false);
      return audioBuffer;
    } catch (err) {
      console.error('Failed to generate speech:', err);
      setError('Failed to generate speech');
      setIsLoading(false);
      return null;
    }
  };

  const playAudio = async (audioBuffer) => {
    try {
      const AudioProcessor = (await import('../services/audioProcessor')).default;
      await AudioProcessor.playAudio(audioBuffer);
      return true;
    } catch (err) {
      console.error('Failed to play audio:', err);
      setError('Failed to play audio');
      return false;
    }
  };

  return {
    isInitialized,
    availableVoices,
    isLoading,
    error,
    generateSpeech,
    playAudio
  };
};
