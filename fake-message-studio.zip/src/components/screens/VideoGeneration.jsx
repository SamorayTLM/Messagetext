import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, Container, IconButton, Paper, LinearProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useAppContext } from '../../contexts/AppContext';

const VideoGeneration = () => {
  const navigate = useNavigate();
  const { project, updateProject, saveProject, updateUi } = useAppContext();
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('Preparing assets...');
  const [error, setError] = useState(null);

  // Simulate video generation process
  useEffect(() => {
    let timer;
    let currentProgress = 0;
    
    const simulateProgress = () => {
      // Update progress and status messages
      currentProgress += Math.random() * 5;
      
      if (currentProgress <= 20) {
        setStatus('Preparing assets...');
      } else if (currentProgress <= 40) {
        setStatus('Generating message bubbles...');
      } else if (currentProgress <= 60) {
        setStatus('Processing audio...');
      } else if (currentProgress <= 80) {
        setStatus('Rendering video frames...');
      } else if (currentProgress < 100) {
        setStatus('Finalizing video...');
      }
      
      if (currentProgress >= 100) {
        currentProgress = 100;
        setStatus('Video generation complete!');
        clearInterval(timer);
        
        // In a real app, we would have an actual video file here
        const mockVideoUrl = 'generated_video.mp4';
        
        // Update project with generated video
        updateProject({ 
          generatedVideo: mockVideoUrl 
        });
        
        // Save project to local storage
        saveProject();
        
        // Navigate to final video screen after a short delay
        setTimeout(() => {
          navigate('/video');
        }, 1500);
      }
      
      setProgress(Math.min(currentProgress, 100));
    };
    
    // Start the simulation
    timer = setInterval(simulateProgress, 300);
    
    // Clean up
    return () => clearInterval(timer);
  }, [navigate, updateProject, saveProject]);

  const handleCancel = () => {
    // Show confirmation dialog in a real app
    navigate('/preview');
  };

  return (
    <Container maxWidth="sm" sx={{ py: 2, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={handleCancel} edge="start" color="inherit">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="h1" sx={{ flexGrow: 1, textAlign: 'center' }}>
          Generating Video
        </Typography>
      </Box>

      <Paper elevation={3} sx={{ p: 3, mb: 3, bgcolor: 'background.paper', flexGrow: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Typography variant="h5" gutterBottom>
            Creating Your Video
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Please wait while we generate your fake message story video.
          </Typography>
        </Box>
        
        <Box sx={{ width: '100%', mb: 2 }}>
          <LinearProgress variant="determinate" value={progress} sx={{ height: 10, borderRadius: 5 }} />
        </Box>
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
          <Typography variant="body2" color="text.secondary">
            {status}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {Math.round(progress)}%
          </Typography>
        </Box>
        
        {error && (
          <Typography variant="body2" color="error" sx={{ mt: 2 }}>
            {error}
          </Typography>
        )}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 'auto' }}>
        <Button 
          variant="outlined" 
          color="inherit"
          onClick={handleCancel}
        >
          Cancel
        </Button>
      </Box>
    </Container>
  );
};

export default VideoGeneration;
