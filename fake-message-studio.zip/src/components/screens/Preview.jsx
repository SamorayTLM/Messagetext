import React, { useState } from 'react';
import { Box, Typography, Button, Container, IconButton, Paper, Tabs, Tab, Slider } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import { useAppContext } from '../../contexts/AppContext';

// Mock message bubble component - in a real app, this would be more sophisticated
const MessageBubble = ({ text, isUser, sender }) => (
  <Box 
    sx={{ 
      display: 'flex', 
      justifyContent: isUser ? 'flex-end' : 'flex-start',
      mb: 1.5
    }}
  >
    <Paper
      elevation={1}
      sx={{
        p: 1.5,
        maxWidth: '80%',
        borderRadius: 2,
        bgcolor: isUser ? 'primary.main' : 'background.paper',
        color: isUser ? 'primary.contrastText' : 'text.primary',
      }}
    >
      {sender && (
        <Typography variant="caption" sx={{ fontWeight: 'bold', display: 'block', mb: 0.5 }}>
          {sender}
        </Typography>
      )}
      <Typography variant="body2">{text}</Typography>
    </Paper>
  </Box>
);

const Preview = () => {
  const navigate = useNavigate();
  const { project, updateProject, saveProject } = useAppContext();
  const { script, characters, selectedVoices, selectedBackground } = project;
  
  const [activeTab, setActiveTab] = useState(0);
  const [messageStyle, setMessageStyle] = useState(project.messageStyle || 'modern');
  const [animationSpeed, setAnimationSpeed] = useState(1);
  
  // Parse script into message objects
  const messages = parseScript(script);
  
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  const handleStyleChange = (style) => {
    setMessageStyle(style);
  };
  
  const handleSpeedChange = (event, newValue) => {
    setAnimationSpeed(newValue);
  };
  
  const handleBack = () => {
    navigate('/background');
  };
  
  const handleNext = () => {
    // Update project with preview settings
    updateProject({ messageStyle });
    
    // Save project to local storage
    saveProject();
    
    // Navigate to next screen
    navigate('/generate');
  };
  
  // Simple function to parse script into message objects
  // In a real implementation, this would be more sophisticated
  function parseScript(scriptText) {
    const lines = scriptText.split('\n');
    const parsedMessages = [];
    
    lines.forEach(line => {
      const match = line.match(/^([A-Za-z0-9_]+):\s*(.*)/);
      if (match && match[1] && match[2]) {
        parsedMessages.push({
          sender: match[1],
          text: match[2],
          isUser: match[1] === characters[0] // Assume first character is the "user"
        });
      }
    });
    
    return parsedMessages;
  }
  
  return (
    <Container maxWidth="sm" sx={{ py: 2, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={handleBack} edge="start" color="inherit">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="h1" sx={{ flexGrow: 1, textAlign: 'center' }}>
          Preview & Customize
        </Typography>
      </Box>
      
      <Tabs
        value={activeTab}
        onChange={handleTabChange}
        variant="fullWidth"
        sx={{ mb: 2 }}
      >
        <Tab label="Preview" />
        <Tab label="Customize" />
      </Tabs>
      
      {activeTab === 0 ? (
        <Paper 
          elevation={3} 
          sx={{ 
            p: 2, 
            mb: 3, 
            bgcolor: 'background.paper', 
            flexGrow: 1, 
            overflowY: 'auto',
            backgroundImage: `url(${selectedBackground})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            position: 'relative'
          }}
        >
          <Box 
            sx={{ 
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              bgcolor: 'rgba(0,0,0,0.5)',
              zIndex: 0
            }} 
          />
          
          <Box sx={{ position: 'relative', zIndex: 1 }}>
            {messages.map((message, index) => (
              <MessageBubble 
                key={index}
                text={message.text}
                isUser={message.isUser}
                sender={message.sender}
              />
            ))}
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <Button
              variant="contained"
              color="secondary"
              startIcon={<PlayArrowIcon />}
            >
              Play Preview
            </Button>
          </Box>
        </Paper>
      ) : (
        <Paper elevation={3} sx={{ p: 2, mb: 3, bgcolor: 'background.paper', flexGrow: 1, overflowY: 'auto' }}>
          <Typography variant="subtitle1" gutterBottom>
            Message Style
          </Typography>
          
          <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
            <Button
              variant={messageStyle === 'modern' ? 'contained' : 'outlined'}
              onClick={() => handleStyleChange('modern')}
            >
              Modern
            </Button>
            <Button
              variant={messageStyle === 'classic' ? 'contained' : 'outlined'}
              onClick={() => handleStyleChange('classic')}
            >
              Classic
            </Button>
            <Button
              variant={messageStyle === 'bubble' ? 'contained' : 'outlined'}
              onClick={() => handleStyleChange('bubble')}
            >
              Bubble
            </Button>
          </Box>
          
          <Typography variant="subtitle1" gutterBottom>
            Animation Speed
          </Typography>
          
          <Box sx={{ px: 2 }}>
            <Slider
              value={animationSpeed}
              min={0.5}
              max={2}
              step={0.1}
              onChange={handleSpeedChange}
              valueLabelDisplay="auto"
              marks={[
                { value: 0.5, label: 'Slow' },
                { value: 1, label: 'Normal' },
                { value: 2, label: 'Fast' }
              ]}
            />
          </Box>
        </Paper>
      )}
      
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 'auto' }}>
        <Button 
          variant="outlined" 
          color="inherit"
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
        >
          Back
        </Button>
        
        <Button 
          variant="contained" 
          color="primary"
          endIcon={<ArrowForwardIcon />}
          onClick={handleNext}
        >
          Next: Generate Video
        </Button>
      </Box>
    </Container>
  );
};

export default Preview;
