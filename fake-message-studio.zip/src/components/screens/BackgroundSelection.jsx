import React, { useState } from 'react';
import { Box, Typography, Button, Container, IconButton, Paper, Grid, Card, CardMedia, CardActionArea } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { useAppContext } from '../../contexts/AppContext';

// Mock background options - in a real app, these would be actual images
const BACKGROUND_OPTIONS = [
  { id: 'minecraft', name: 'Minecraft Parkour', category: 'gaming', path: '/assets/backgrounds/minecraft.jpg' },
  { id: 'subway', name: 'Subway', category: 'urban', path: '/assets/backgrounds/subway.jpg' },
  { id: 'asmr', name: 'ASMR Studio', category: 'relaxing', path: '/assets/backgrounds/asmr.jpg' },
  { id: 'nature', name: 'Forest', category: 'nature', path: '/assets/backgrounds/forest.jpg' },
  { id: 'beach', name: 'Beach Sunset', category: 'nature', path: '/assets/backgrounds/beach.jpg' },
  { id: 'citynight', name: 'City Night', category: 'urban', path: '/assets/backgrounds/citynight.jpg' },
  { id: 'gaming', name: 'Gaming Setup', category: 'gaming', path: '/assets/backgrounds/gaming.jpg' },
  { id: 'space', name: 'Space', category: 'abstract', path: '/assets/backgrounds/space.jpg' },
];

// Group backgrounds by category
const CATEGORIES = {
  gaming: 'Gaming',
  urban: 'Urban',
  relaxing: 'Relaxing',
  nature: 'Nature',
  abstract: 'Abstract'
};

const BackgroundSelection = () => {
  const navigate = useNavigate();
  const { project, updateProject, saveProject } = useAppContext();
  const [selectedBackground, setSelectedBackground] = useState(project.selectedBackground || null);
  const [activeCategory, setActiveCategory] = useState('all');

  const handleBackgroundSelect = (backgroundId) => {
    setSelectedBackground(backgroundId);
  };

  const handleCategoryChange = (category) => {
    setActiveCategory(category);
  };

  const handleBack = () => {
    navigate('/voices');
  };

  const handleNext = () => {
    // Update project with selected background
    updateProject({ selectedBackground });
    
    // Save project to local storage
    saveProject();
    
    // Navigate to next screen
    navigate('/preview');
  };

  // Filter backgrounds by category
  const filteredBackgrounds = activeCategory === 'all' 
    ? BACKGROUND_OPTIONS 
    : BACKGROUND_OPTIONS.filter(bg => bg.category === activeCategory);

  return (
    <Container maxWidth="sm" sx={{ py: 2, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={handleBack} edge="start" color="inherit">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="h1" sx={{ flexGrow: 1, textAlign: 'center' }}>
          Select Background
        </Typography>
      </Box>

      <Box sx={{ mb: 2, display: 'flex', overflowX: 'auto', pb: 1 }}>
        <Button 
          variant={activeCategory === 'all' ? 'contained' : 'outlined'}
          color="secondary"
          size="small"
          onClick={() => handleCategoryChange('all')}
          sx={{ mr: 1, whiteSpace: 'nowrap' }}
        >
          All
        </Button>
        {Object.entries(CATEGORIES).map(([key, label]) => (
          <Button 
            key={key}
            variant={activeCategory === key ? 'contained' : 'outlined'}
            color="secondary"
            size="small"
            onClick={() => handleCategoryChange(key)}
            sx={{ mr: 1, whiteSpace: 'nowrap' }}
          >
            {label}
          </Button>
        ))}
      </Box>

      <Paper elevation={3} sx={{ p: 2, mb: 3, bgcolor: 'background.paper', flexGrow: 1, overflowY: 'auto' }}>
        <Grid container spacing={2}>
          {filteredBackgrounds.map((background) => (
            <Grid item xs={6} key={background.id}>
              <Card 
                raised={selectedBackground === background.id}
                sx={{ 
                  border: selectedBackground === background.id ? '2px solid' : '2px solid transparent',
                  borderColor: 'primary.main',
                  transition: 'all 0.2s'
                }}
              >
                <CardActionArea onClick={() => handleBackgroundSelect(background.id)}>
                  <CardMedia
                    component="div"
                    sx={{
                      height: 120,
                      bgcolor: 'grey.800',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    {/* In a real app, this would be an actual image */}
                    <Typography variant="body2" color="text.secondary">
                      {background.name}
                    </Typography>
                  </CardMedia>
                </CardActionArea>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 'auto' }}>
        <Button 
          variant="outlined" 
          color="inherit"
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
        >
          Back
        </Button>
        
        <Button 
          variant="contained" 
          color="primary"
          endIcon={<ArrowForwardIcon />}
          onClick={handleNext}
          disabled={!selectedBackground}
        >
          Next: Preview
        </Button>
      </Box>
    </Container>
  );
};

export default BackgroundSelection;
