import React from 'react';
import { Box, Typography, Button, Container, IconButton, Paper } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ShareIcon from '@mui/icons-material/Share';
import DownloadIcon from '@mui/icons-material/Download';
import HomeIcon from '@mui/icons-material/Home';
import { useAppContext } from '../../contexts/AppContext';

const FinalVideo = () => {
  const navigate = useNavigate();
  const { project, resetProject } = useAppContext();
  const { generatedVideo } = project;

  const handleBack = () => {
    navigate('/preview');
  };

  const handleDownload = () => {
    // In a real app, this would trigger a download of the video file
    console.log('Downloading video:', generatedVideo);
    alert('Download started! (This is a simulation)');
  };

  const handleShare = () => {
    // In a real app, this would open the native share dialog
    console.log('Sharing video:', generatedVideo);
    
    // Check if Web Share API is available
    if (navigator.share) {
      navigator.share({
        title: 'My Fake Message Story',
        text: 'Check out this fake message story I created!',
        url: window.location.href,
      })
      .catch((error) => console.log('Error sharing:', error));
    } else {
      alert('Sharing is not supported on this browser. (This is a simulation)');
    }
  };

  const handleCreateNew = () => {
    resetProject();
    navigate('/');
  };

  return (
    <Container maxWidth="sm" sx={{ py: 2, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={handleBack} edge="start" color="inherit">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="h1" sx={{ flexGrow: 1, textAlign: 'center' }}>
          Your Video
        </Typography>
      </Box>

      <Paper elevation={3} sx={{ p: 2, mb: 3, bgcolor: 'background.paper', flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
          {/* Video player placeholder */}
          <Box 
            sx={{ 
              width: '100%', 
              aspectRatio: '9/16',
              bgcolor: 'black',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 3
            }}
          >
            <Typography variant="body2" color="text.secondary">
              Video Player (Simulation)
            </Typography>
          </Box>
          
          <Typography variant="h6" gutterBottom>
            Your video is ready!
          </Typography>
          
          <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
            You can now download your video or share it directly to social media.
          </Typography>
          
          <Box sx={{ display: 'flex', gap: 2, width: '100%', justifyContent: 'center' }}>
            <Button
              variant="contained"
              color="primary"
              startIcon={<DownloadIcon />}
              onClick={handleDownload}
            >
              Download
            </Button>
            
            <Button
              variant="contained"
              color="secondary"
              startIcon={<ShareIcon />}
              onClick={handleShare}
            >
              Share
            </Button>
          </Box>
        </Box>
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 'auto' }}>
        <Button 
          variant="outlined" 
          color="inherit"
          startIcon={<HomeIcon />}
          onClick={handleCreateNew}
          fullWidth
        >
          Create New Story
        </Button>
      </Box>
    </Container>
  );
};

export default FinalVideo;
