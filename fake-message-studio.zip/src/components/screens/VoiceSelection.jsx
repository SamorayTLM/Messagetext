import React, { useState } from 'react';
import { Box, Typography, Button, Container, IconButton, Paper, FormControl, InputLabel, MenuItem, Select, Grid } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import VolumeUpIcon from '@mui/icons-material/VolumeUp';
import { useAppContext } from '../../contexts/AppContext';

// Mock voice options - in a real app, these would come from an API
const VOICE_OPTIONS = [
  { id: 'male1', name: 'Male 1', gender: 'male' },
  { id: 'male2', name: 'Male 2', gender: 'male' },
  { id: 'male3', name: 'Male 3 (Deep)', gender: 'male' },
  { id: 'female1', name: 'Female 1', gender: 'female' },
  { id: 'female2', name: 'Female 2', gender: 'female' },
  { id: 'female3', name: 'Female 3 (Young)', gender: 'female' },
  { id: 'robot', name: 'Robot Voice', gender: 'neutral' },
];

const VoiceSelection = () => {
  const navigate = useNavigate();
  const { project, updateProject, saveProject } = useAppContext();
  const { characters, selectedVoices } = project;
  
  // Initialize state with existing selections or defaults
  const [voiceSelections, setVoiceSelections] = useState(() => {
    const initialSelections = {};
    characters.forEach(character => {
      initialSelections[character] = selectedVoices[character] || '';
    });
    return initialSelections;
  });

  const handleVoiceChange = (character, voiceId) => {
    setVoiceSelections(prev => ({
      ...prev,
      [character]: voiceId
    }));
  };

  const handlePlayVoice = (voiceId) => {
    // In a real app, this would play a sample of the voice
    console.log(`Playing sample of voice: ${voiceId}`);
    // Could use Web Speech API or a custom audio API here
  };

  const handleBack = () => {
    navigate('/script');
  };

  const handleNext = () => {
    // Update project with selected voices
    updateProject({ selectedVoices: voiceSelections });
    
    // Save project to local storage
    saveProject();
    
    // Navigate to next screen
    navigate('/background');
  };

  // Check if all characters have voices assigned
  const allVoicesSelected = characters.every(character => voiceSelections[character]);

  return (
    <Container maxWidth="sm" sx={{ py: 2, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={handleBack} edge="start" color="inherit">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="h1" sx={{ flexGrow: 1, textAlign: 'center' }}>
          Select Character Voices
        </Typography>
      </Box>

      <Paper elevation={3} sx={{ p: 2, mb: 3, bgcolor: 'background.paper', flexGrow: 1, overflowY: 'auto' }}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Choose a voice for each character in your story:
        </Typography>
        
        {characters.map((character) => (
          <Box key={character} sx={{ mb: 3 }}>
            <Typography variant="subtitle1" sx={{ mb: 1 }}>
              {character}
            </Typography>
            
            <Grid container spacing={1} alignItems="center">
              <Grid item xs={9}>
                <FormControl fullWidth size="small">
                  <InputLabel id={`voice-select-label-${character}`}>Voice</InputLabel>
                  <Select
                    labelId={`voice-select-label-${character}`}
                    value={voiceSelections[character]}
                    label="Voice"
                    onChange={(e) => handleVoiceChange(character, e.target.value)}
                  >
                    {VOICE_OPTIONS.map((voice) => (
                      <MenuItem key={voice.id} value={voice.id}>
                        {voice.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={3}>
                <Button
                  variant="outlined"
                  color="secondary"
                  disabled={!voiceSelections[character]}
                  onClick={() => handlePlayVoice(voiceSelections[character])}
                  startIcon={<VolumeUpIcon />}
                  size="small"
                  fullWidth
                >
                  Test
                </Button>
              </Grid>
            </Grid>
          </Box>
        ))}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 'auto' }}>
        <Button 
          variant="outlined" 
          color="inherit"
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
        >
          Back
        </Button>
        
        <Button 
          variant="contained" 
          color="primary"
          endIcon={<ArrowForwardIcon />}
          onClick={handleNext}
          disabled={!allVoicesSelected}
        >
          Next: Select Background
        </Button>
      </Box>
    </Container>
  );
};

export default VoiceSelection;
