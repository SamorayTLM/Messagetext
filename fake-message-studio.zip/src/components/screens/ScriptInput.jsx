import React, { useState } from 'react';
import { Box, Typography, TextField, Button, Container, IconButton, Paper } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { useAppContext } from '../../contexts/AppContext';

const ScriptInput = () => {
  const navigate = useNavigate();
  const { project, updateProject, saveProject } = useAppContext();
  const [script, setScript] = useState(project.script || '');

  const handleScriptChange = (e) => {
    setScript(e.target.value);
  };

  const handleBack = () => {
    navigate('/');
  };

  const handleNext = () => {
    // Extract character names from script (simple implementation)
    const characters = extractCharacters(script);
    
    // Update project with script and characters
    updateProject({ 
      script,
      characters
    });
    
    // Save project to local storage
    saveProject();
    
    // Navigate to next screen
    navigate('/voices');
  };

  // Simple function to extract character names from script
  // In a real implementation, this would be more sophisticated
  const extractCharacters = (text) => {
    const lines = text.split('\n');
    const characterSet = new Set();
    
    lines.forEach(line => {
      const match = line.match(/^([A-Za-z0-9_]+):/);
      if (match && match[1]) {
        characterSet.add(match[1]);
      }
    });
    
    return Array.from(characterSet);
  };

  return (
    <Container maxWidth="sm" sx={{ py: 2, height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton onClick={handleBack} edge="start" color="inherit">
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h6" component="h1" sx={{ flexGrow: 1, textAlign: 'center' }}>
          Write Your Script
        </Typography>
      </Box>

      <Paper elevation={3} sx={{ p: 2, mb: 3, bgcolor: 'background.paper' }}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Write your message script below. Format each line as "Character: Message" to automatically identify speakers.
        </Typography>
        
        <TextField
          multiline
          fullWidth
          minRows={10}
          maxRows={20}
          variant="outlined"
          placeholder="Example:
John: Hey, how's it going?
Sarah: Pretty good! Did you hear about what happened yesterday?
John: No, what happened?"
          value={script}
          onChange={handleScriptChange}
          sx={{ mb: 2 }}
        />
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 'auto' }}>
        <Button 
          variant="outlined" 
          color="inherit"
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
        >
          Back
        </Button>
        
        <Button 
          variant="contained" 
          color="primary"
          endIcon={<ArrowForwardIcon />}
          onClick={handleNext}
          disabled={!script.trim()}
        >
          Next: Select Voices
        </Button>
      </Box>
    </Container>
  );
};

export default ScriptInput;
