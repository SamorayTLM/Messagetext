import React from 'react';
import { Box, Typography, Button, Container } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../../contexts/AppContext';

const Welcome = () => {
  const navigate = useNavigate();
  const { loadProject } = useAppContext();

  const handleCreateNew = () => {
    navigate('/script');
  };

  const handleLoadProject = () => {
    const success = loadProject();
    if (success) {
      navigate('/script');
    } else {
      // Could show an error message here
      console.error('Failed to load project');
    }
  };

  return (
    <Container maxWidth="sm" sx={{ py: 4, height: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Typography variant="h3" component="h1" gutterBottom>
          Fake Message Studio
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" sx={{ mb: 4 }}>
          Create viral fake message story videos on your mobile device
        </Typography>
      </Box>

      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <Button 
          variant="contained" 
          color="primary" 
          size="large" 
          fullWidth
          onClick={handleCreateNew}
        >
          Create New Story
        </Button>
        
        <Button 
          variant="outlined" 
          color="secondary" 
          size="large" 
          fullWidth
          onClick={handleLoadProject}
        >
          Load Saved Project
        </Button>
        
        <Button 
          variant="text" 
          color="inherit" 
          size="large" 
          fullWidth
        >
          Tutorial
        </Button>
      </Box>
      
      <Box sx={{ mt: 'auto', pt: 4, textAlign: 'center' }}>
        <Typography variant="body2" color="text.secondary">
          Mobile version of Diffusion Studio's fake message stories
        </Typography>
      </Box>
    </Container>
  );
};

export default Welcome;
