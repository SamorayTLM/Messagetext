# Fake Message Studio - Project Structure

## Overview
This document outlines the structure of the Fake Message Studio mobile web application, designed to provide a mobile-compatible alternative to Diffusion Studio's fake message stories feature.

## Technology Stack
- **Frontend Framework**: React.js with React Hooks
- **UI Framework**: Material UI with custom styling for mobile optimization
- **State Management**: React Context API
- **Styling**: CSS-in-JS with styled-components
- **Media Handling**: HTML5 Canvas and Web Audio API
- **Build Tool**: Vite for fast development and optimized production builds
- **Deployment**: Static site hosting

## Project Directory Structure

```
fake-message-studio/
├── public/
│   ├── assets/
│   │   ├── backgrounds/
│   │   ├── fonts/
│   │   ├── icons/
│   │   └── sounds/
│   ├── favicon.ico
│   └── index.html
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Button.jsx
│   │   │   ├── Input.jsx
│   │   │   ├── Modal.jsx
│   │   │   └── ...
│   │   ├── layout/
│   │   │   ├── Header.jsx
│   │   │   ├── Footer.jsx
│   │   │   ├── Navigation.jsx
│   │   │   └── ...
│   │   ├── screens/
│   │   │   ├── Welcome.jsx
│   │   │   ├── ScriptInput.jsx
│   │   │   ├── VoiceSelection.jsx
│   │   │   ├── BackgroundSelection.jsx
│   │   │   ├── Preview.jsx
│   │   │   ├── VideoGeneration.jsx
│   │   │   └── FinalVideo.jsx
│   │   └── features/
│   │       ├── MessageBubble.jsx
│   │       ├── VoiceSelector.jsx
│   │       ├── BackgroundGrid.jsx
│   │       ├── VideoPlayer.jsx
│   │       └── ...
│   ├── contexts/
│   │   ├── AppContext.jsx
│   │   ├── ProjectContext.jsx
│   │   └── ...
│   ├── hooks/
│   │   ├── useMediaQuery.js
│   │   ├── useLocalStorage.js
│   │   ├── useAudioProcessing.js
│   │   └── ...
│   ├── services/
│   │   ├── messageGenerator.js
│   │   ├── audioProcessor.js
│   │   ├── videoRenderer.js
│   │   ├── storageService.js
│   │   └── ...
│   ├── utils/
│   │   ├── formatters.js
│   │   ├── validators.js
│   │   ├── mediaHelpers.js
│   │   └── ...
│   ├── styles/
│   │   ├── theme.js
│   │   ├── globalStyles.js
│   │   └── ...
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── package.json
├── vite.config.js
├── .gitignore
├── README.md
└── LICENSE
```

## Core Modules

### 1. User Interface Components
- **Common Components**: Reusable UI elements like buttons, inputs, and modals
- **Layout Components**: Structural elements like headers, footers, and navigation
- **Screen Components**: Full-screen views for each step of the creation process
- **Feature Components**: Specialized components for specific functionality

### 2. State Management
- **App Context**: Global application state and settings
- **Project Context**: Current project data and editing state
- **Local Storage**: Persistence of user projects and preferences

### 3. Core Services
- **Message Generator**: Creates visual message bubbles from script text
- **Audio Processor**: Handles voice selection and audio synthesis
- **Video Renderer**: Combines message visuals with audio and background
- **Storage Service**: Manages saving and loading projects

### 4. Utility Functions
- **Formatters**: Text and data formatting helpers
- **Validators**: Input validation functions
- **Media Helpers**: Utilities for working with audio, video, and images

## Responsive Design Implementation
- Mobile-first approach with CSS media queries
- Flexible layouts using CSS Grid and Flexbox
- Touch-optimized controls and gestures
- Orientation-specific layouts for portrait and landscape modes

## Performance Optimizations
- Lazy loading of non-critical components and assets
- Efficient canvas rendering with requestAnimationFrame
- Web Worker utilization for intensive processing tasks
- Optimized asset loading and caching strategies
